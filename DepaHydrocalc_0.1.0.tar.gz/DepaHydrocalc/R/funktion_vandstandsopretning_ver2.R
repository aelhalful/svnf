#' Adjustment of logger data to measured water scake data

#' @details Regression tree with boosting (XG boost) is used to adjust the logger  data to the measured data. Cross-validation is used to tjune the 
#' hyperparameters of XG boost.
#' @author Johan Lassen
#' @param skalavandstand (the measured water levels or scales) a dataframe with: ID, boardnr, Tidspunkt (timestamp: YYmmddHHMM), Vandstand
#' @param loggervandstand (the waterlevels or scales from the data logger) a dataframe with: ID, boardnr, Tidspunkt, Vandstand
#'
#' @return a dataframe with: ID, boardnr, Tidspunkt, Vandstand, Tid, Fit, VandstandEdit
#' @examples
#' @export ...
#' @note  Only for ...
#' @references Hedeselskabet 2000 ....
#' @references AU 2000 ....

funktion_vandstandsopretning <- function(loggervandstand,skalavandstand){


unikke_id_boardno_serialno <- unique(skalavandstand[,c("ID","boardnr")])   
temp  <- unique(loggervandstand[,c("ID","boardnr")])   

unikke_id_boardno_serialno <- merge(unikke_id_boardno_serialno,temp,by.x=c("ID","boardnr"),by.y=c("ID","boardnr"))

opsamling <- numeric(1)
for(i in 1:nrow(unikke_id_boardno_serialno)){
funktion_vandstandsopretning_1 <- subset(skalavandstand,ID == unikke_id_boardno_serialno$ID[i] & 
                                           boardnr==unikke_id_boardno_serialno$boardnr[i])  
  
funktion_vandstandsopretning_2 <- subset(loggervandstand,ID == unikke_id_boardno_serialno$ID[i] & 
                                           boardnr==unikke_id_boardno_serialno$boardnr[i]) 
testr <- nrow(funktion_vandstandsopretning_2)
if(testr>4*24){

fraktiler <- quantile(funktion_vandstandsopretning_2$Vandstand,probs = c(0.00001,0.99999))



funktion_vandstandsopretning_2 <- subset(funktion_vandstandsopretning_2,Vandstand > fraktiler[1] & Vandstand < fraktiler[2])

funktion_vandstandsopretning_1 <- subset(funktion_vandstandsopretning_1,Tidspunkt >= min(funktion_vandstandsopretning_2$Tidspunkt))

funktion_vandstandsopretning_1$loggervandstand <- approx(funktion_vandstandsopretning_2$Tidspunkt,funktion_vandstandsopretning_2$Vandstand,
                                                                                                 xout=funktion_vandstandsopretning_1$Tidspunkt)$y

funktion_vandstandsopretning_1$Difft_loggervandstand <- approx(funktion_vandstandsopretning_2$Tidspunkt,funktion_vandstandsopretning_2$Difft,
                                                         xout=funktion_vandstandsopretning_1$Tidspunkt)$y

funktion_vandstandsopretning_1 <- subset(funktion_vandstandsopretning_1,Difft_loggervandstand<=60*60)


funktion_vandstandsopretning_1$Tid <- strptime(funktion_vandstandsopretning_1$Tidspunkt,"%Y%m%d%H%M")

funktion_vandstandsopretning_2$Tid <- strptime(funktion_vandstandsopretning_2$Tidspunkt,"%Y%m%d%H%M")


funktion_vandstandsopretning_1$TidN <- as.numeric(scale(as.numeric(funktion_vandstandsopretning_1$Tid)))


funktion_vandstandsopretning_1$Diff <- funktion_vandstandsopretning_1$Vandstand-funktion_vandstandsopretning_1$loggervandstand

#tree <- rpart(Vandstand ~ TidN + loggervandstand, data=funktion_vandstandsopretning_1)
#tree <- rpart(Diff ~ TidN, data=funktion_vandstandsopretning_1)


#predict(tree,funktion_vandstandsopretning_1)

#rf.fit <- randomForest(Vandstand ~ loggervandstand, data=funktion_vandstandsopretning_1, ntree=10000,
#                       keep.forest=FALSE, importance=TRUE)


train_x = data.matrix(funktion_vandstandsopretning_1[,c("Tidspunkt")])
train_y = data.matrix(funktion_vandstandsopretning_1[, "Diff"])

#train_y = train[,13]

#test_x = data.matrix(test[, -13])
#test_y = test[, 13]



xgb_train = xgb.DMatrix(data = train_x, label = train_y)
xgbc = xgboost(data = xgb_train, max.depth = 1, nrounds = 100)
#print(xgbc)




#xgb_test = xgb.DMatrix(data = test_x, label = test_y)

train_x_1 = data.matrix(funktion_vandstandsopretning_2[,c("Tidspunkt")])


#funktion_vandstandsopretning_1$Fit <- rf.fit$predicted
#funktion_vandstandsopretning_1$Fit <- predict(xgbc,train_x)


funktion_vandstandsopretning_2$Fit <- predict(xgbc,train_x_1)
funktion_vandstandsopretning_2$VandstandEdit <- funktion_vandstandsopretning_2$Vandstand+funktion_vandstandsopretning_2$Fit


fraktiler <- quantile(funktion_vandstandsopretning_2$VandstandEdit,probs = c(0.0001,0.9999))

funktion_vandstandsopretning_2 <- subset(funktion_vandstandsopretning_2,VandstandEdit>fraktiler[1] & VandstandEdit < fraktiler[2])

opsamling[i] <- list(funktion_vandstandsopretning_2)
print(i/nrow(unikke_id_boardno_serialno))
}
}

delete.NULLs  <-  function(x.list){   # delele null/empty entries in a list
  x.list[unlist(lapply(x.list, length) != 0)]
}


Resultat <- do.call("rbind",opsamling)
}

