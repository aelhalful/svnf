#' 'Reverse engineering' to the coefficients \eqn{A_{t}}, \eqn{N_{t}} and \eqn{H_{0,t}} for the equation \eqn{Q_{t}=A_{t}*(H_{t}-H_{0,t})^{N_{t}}}. Calculation of the steering curve,
#' \eqn{H_{s,t}}.
#'
#' @details Given input of pre-defined rating curve(s), type of rating curve(s) and corresponding measurements of water level water scale and water flow, for each rating curve
#' the parameter values \eqn{A_{t}}, \eqn{N_{t}} and \eqn{H_{0,t}} of the equation \eqn{Q_{t}=A_{t}*(H_{t}-H_{0,t})^{N_{t}}}, are calculated by 'reverse engineering'. Here,
#' \eqn{Q_{t}} equals the water flow a time stamp \eqn{t}, \eqn{H_{t}} equals the water scale, \eqn{A_{t}}, \eqn{N_{t}} and \eqn{H_{0,t}} are parameter values,
#' where \eqn{H_{0,t}} represents the water scale corresponding to zero water flow \eqn{Q_{t}}=0.
#'
#' The steering height at a pre set control water flow is subsequently calculated as: \eqn{H_{s,t} = Q_{Control}/A_{t})^{1/N_{t}}/+H_{0,t} } 
#' 
#' A rating curve is defined uniquely by station ID, Serial no., board no. and a sub curve ID. With resepct to station ID, board no and serial no, 
#' these rating curves cannot overlap in time. But each unique station ID, board no and serial no may have up to 3 synchrononously defined subcurves. A 
#' subcurve represents a piecewise rating curve, where the parameter values are dependent on water scale (break points). The piecewise regression is discontinous in it 
#' its conceptual formulation, i.e. both slope and intercept may differ between each subcurve. 
#' 
#' #' Four different variants of the water flow model are used:
#'
#' 1) The proportional method where the parameter values of \eqn{A_{t}} is dynamic and \eqn{N_{t}} and \eqn{H_{0,t}} are held constant, i.e. \eqn{Q_{t}=A_{t}*(H_{t}-H_{0})^{N}}.
#'
#' 2) The Focal method where where the parameter values of \eqn{A_{t}} and \eqn{N_{t}} are both duynamic and \eqn{H_{0,t}} is held constant, i.e. \eqn{Q_{t}=A_{t}*(H_{t}-H_{0})^{N_{t}}}
#'
#' 3) The Displacement method where \eqn{H_{0,t}} is dynamic and the rest of the parameters are held constant, i.e. \eqn{Q_{t}=A*(H_{t}-H_{0,t})^{N}}
#'
#' 4) The fixed model where the parameter values of \eqn{A_{t}}, \eqn{N_{t}} and \eqn{H_{0,t}} are all held constant, i.e. \eqn{Q_{t}=A*(H_{t}-H_{0})^{N}}
#'
#' The dynamic parameter values are fitted from the data of each measuring date.
#'
#' Ad.1: For the Proportional method the dynamic parameter value \eqn{A_{t}} extracted at each time stamp \eqn{t}: \eqn{A_{t}=Q_{t}/(H_{t}-H_{0})^{N}}
#'
#' Ad.2: For the Focal method the two dynamic parameter values  \eqn{A_{t}} and \eqn{N_{t}} are calculated using the corresponding data of water scale and flow and
#' a predefined 'focal point' which is constant for a given rating curve. The focal point represents an estimated treshold of corresponding water scale  and
#' waterflow when friction approaches a limit of zero friction. Having two points for each time stamp, the two parameters can be found. For example from a logaritmic transform:
#'
#' \eqn{log(Q_{t})=log(A_{t})+N_{t}*log(H_{t}-H_{0})}.
#'
#' \eqn{log(Q_{Focal})=log(A_{t})+N_{t}*log(H_{Focal,t}-H_{0})}
#'
#' Ad. 3: For the displacement method the parameter value \eqn{H_{0,t}} is calculated as: \eqn{H_{0,t}=((H_{t}-Q_{t})/{A})^{N^{-1}}}
#' 
#' The steering/friction scale \eqn{H_{s,t}} represents a calculated water scale corresponding to a fixed/specified water flow. The higher the friction scale, the
#' higher the friction.
#' 
#' Pr. rating curve the Water scale is calculated as water level subtracted the start level (an interpolated (or extrapolated) value) of the scale at the start of the rating curve. By doing this the parameter values
#' \eqn{H_{0}} and \eqn{H_{max}} are related correctly to the water scale.    
#' 
#' @author Johan Lassen
#' @param grundkurve A data.frame:ID (integer) = unique id of station, boardno (integer) = unique id within station id,
#' SERIALNO (integer) = unique id within station id, fromdate (time) = timestamp formatted as the integer yyyy-mm-dd hh:mm:ss,
#' todate (time) = timestamp formatted as the integer yyyy-mm-dd hh:mm:ss, metode = method (1:Focal method, 2: Proportional method, 3:Displacement method,
#'  4: Constant rating kurve), A (float) = parameter value, N (float) = parameter value,
#' H0 (float) = parameter value on water scale (i.e. not water level), Subcurve (integer) = unique id within station, SERIALNO and boardno, 
#' Hmax (float) = upper height limit for the QH curve, Hbrendpkt (float) = the upper height for the QH curve (focal point method),
#' Kote = interpolated level at the start time stamp of the rating curve. 
#' @param qHt A data.frame: ID (integer) = unique id of station, boardno (integer) = unique id within station id, 
#' SERIALNO (integer) = unique id within station id, q (float) = water flow, H (float) = water level (not water scale!), t (time) = timestamp formatted as yyyy-mm-dd hh:mm:ss  
#' Tidspunkt (integer) = timestamp formatted as the integer yymmddhhmm, LEVELVALUE (float) = registered level
#' @return
#' ' \itemize{
#'  \item{df1}{The first data frame.}
#'  \item{df2}{The second data frame.}
#'  \item{df3}{The third data frame.}
#' }
#'  The qHt data.frame added with: ADyn (float) = parameter value, NDyn (float) = parameter value, H0Dyn (float) = parameter value,
#' Hm (float) = waterlevel minus the rating curve specific start level 
#' @examples set.seed(123) 
#' grundkurve <- data.frame(ID = rep(1, 2),boardno = rep(1, 2),SERIALNO = rep(1, 2),fromdate = seq(from = as.POSIXct("2022-01-01 00:01"),
#' by = "year", length.out = 2),todate = seq(from = as.POSIXct("2022-12-31 23:59"), by = "year", length.out = 2),metode = sample(1:1, 2, replace = TRUE),
#'   Subcurve = c(1,1),A = c(0.7,0.7),N = c(1.6,1.7),H0 = c(0,0),Hmax=c(NA,NA),Hbrendpkt = c(100,100),Kote = c(5,10))
#'   
#'   qHt <- data.frame(ID = rep(1, 12),boardno = rep(1, 12),SERIALNO = rep(1, 12),q = runif(12, 1, 100),H = runif(12, 1, 100),
#'     t = seq(from = as.POSIXct("2022-01-01 12:00"), by = "month", length.out = 12))
#'     qHt$q <- 0.6*(qHt$H/10-0)^1.7
#'     CtrlVandf = 1000
#'     
#'     # Call the function with the demo data: 
#'     
#'     res <- funktion_beregn_koefficienter(grundkurve, qHt, CtrlVandf)
#'     print(res)
#'     
#'     p1 <- ggplot(data=res,aes(x=as.POSIXct(t),y=Hm))+geom_point()+geom_line()
#'     
#'     p2 <- ggplot(data=res,aes(x=as.POSIXct(t),y=q))+geom_line(data=res,aes(x=as.POSIXct(t),y=q))+geom_point()+geom_line()
#'     
#'     p3 <- ggplot(data=res,aes(x=as.POSIXct(t),y=Hsm))+geom_point()+geom_line()
#'     
#'     p4 <- ggplot()+geom_point(data=res,aes(x=as.POSIXct(t),y=H0))+geom_line(data=res,aes(x=as.POSIXct(t),y=H0))+
#'     geom_point(data=res,aes(x=as.POSIXct(t),y=H0Dyn),shape=1,size=1.5)+geom_line(data=res,aes(x=as.POSIXct(t),y=H0Dyn),col="red")
#'     
#'     p5 <- ggplot()+geom_point(data=res,aes(x=as.POSIXct(t),y=A))+geom_line(data=res,aes(x=as.POSIXct(t),y=A))+
#'     geom_point(data=res,aes(x=as.POSIXct(t),y=ADyn),col="red",shape=1,size=1.5)+geom_line(data=res,aes(x=as.POSIXct(t),y=ADyn),col="red")
#'     
#'     p6 <- ggplot()+geom_point(data=res,aes(x=as.POSIXct(t),y=N))+geom_line(data=res,aes(x=as.POSIXct(t),y=N))+
#'     geom_point(data=res,aes(x=as.POSIXct(t),y=NDyn),col="red",shape=1,size=1.5)+geom_line(data=res,aes(x=as.POSIXct(t),y=NDyn),col="red")
#'     
#'     grid.arrange(p1,p2,p3,p4,p5,p6,ncol=1)

#' @note  Det skal testes hvorfor Hm er forskellig for samme dato/måling for hhv. delkurve 1 og 2 for station 26000082. Er dette en bug i koden?
#' @references Hedeselskabet 2000 ....
#' @references AU 2000 ....
  


funktion_beregn_koefficienter <- function(grundkurve,qHt){


  
# Unikke grundkurver (som kan være inddelt i flere delkurver)

unikke_metoder_0 <- merge(grundkurve,qHt,by.x=c("ID","boardno","SERIALNO"),by.y=c("ID","boardno","SERIALNO"))

#unikke_metoder_0$Hm <- unikke_metoder_0$H-unikke_metoder_0$Kote

#unikke_metoder_0$Subcurve <- ifelse(unikke_metoder_0$NSubcurves==2 & unikke_metoder_0$Hm>unikke_metoder_0$Subcurve1,2,1)
#unikke_metoder_0$Subcurve <- ifelse(unikke_metoder_0$NSubcurves==3 & unikke_metoder_0$Hm>unikke_metoder_0$Subcurve2,3,unikke_metoder_0$Subcurve)
#unikke_metoder_0$Subcurve <- ifelse(unikke_metoder_0$NSubcurves==3 & unikke_metoder_0$Hm>unikke_metoder_0$Subcurve1 & 
#                                      unikke_metoder_0$Hm<unikke_metoder_0$Subcurve2,2,unikke_metoder_0$Subcurve)


# Unikke stationer, boardno, serialno og subkurve(ved tilfælde af flere kurver = stykvis lin regression) 
unikke_stationer_boards <- unique(unikke_metoder_0[,c("ID","boardno","SERIALNO","Subcurve")])
opsamling_1 <- numeric(1)
for(aa in 1:nrow(unikke_stationer_boards)){
opsamling <- numeric(1)
  
unikke_metoder <- subset(unikke_metoder_0,ID==unikke_stationer_boards$ID[aa] & boardno == unikke_stationer_boards$boardno[aa] & 
                           SERIALNO == unikke_stationer_boards$SERIALNO[aa] & Subcurve == unikke_stationer_boards$Subcurve[aa])  
  
unikke_metoder <- unique(unikke_metoder[,c("ID","fromdate","todate","metode","boardno","Kote","SERIALNO","Subcurve")])


unikke_metoder <- with(unikke_metoder,unikke_metoder[order(fromdate),])
unikke_metoder$IDGrundkurve <- 1:length(unikke_metoder$fromdate)

unikke_metoder$fromdate <- as.character(unikke_metoder$fromdate)
unikke_metoder$todate <- as.character(unikke_metoder$todate)

unikke_metoder_1 <- data.frame(melt(unikke_metoder,id.vars=c("ID","metode","boardno","IDGrundkurve","Kote","SERIALNO","Subcurve"),measure.vars=c("fromdate","todate")))
unikke_metoder_1$value <- as.character(unikke_metoder_1$value)
unikke_metoder_1$value <- strptime(unikke_metoder_1$value,"%Y-%m-%d %H:%M:%S")

unikke_metoder_1 <- with(unikke_metoder_1,unikke_metoder_1[order(value),])
unikke_metoder_1$t <- unikke_metoder_1$value
unikke_metoder_1 <- data.frame(unikke_metoder_1)

unikke_metoder_1_1 <- with(unikke_metoder_1,data.frame(ID,SERIALNO,"q"=NA,"H"=NA,"t"=value,boardno,Subcurve))

# Overfoersel af ID for grundkurve på de maalte vandstande/vandfoeringer:

qHt_0_1 <- subset(qHt,ID == unikke_stationer_boards$ID[aa] & boardno==unikke_stationer_boards$boardno[aa] & SERIALNO == unikke_stationer_boards$SERIALNO[aa]
                  & t>=min(unikke_metoder_1$t))



if(nrow(qHt_0_1)==0){
  qHt_0_1 <- data.frame("ID"= unikke_stationer_boards$ID[aa],"SERIALNO" = unikke_stationer_boards$SERIALNO[aa],
                        "q"=999999999, "H" =999999999, "t"=unikke_metoder_1$t, "boardno"=unikke_stationer_boards$boardno[aa],
                        Subcurve=unikke_stationer_boards$Subcurve[aa])
}
qHt_0_1$Subcurve=unikke_stationer_boards$Subcurve[aa]

qHt_0_1 <- rbind(qHt_0_1,unikke_metoder_1_1)

qHt_0_1 <- with(qHt_0_1,qHt_0_1[order(t),])

qHt_0_1$IDGrundkurve <- NA
qHt_0_1$IDGrundkurve[1] <- min(unikke_metoder_1$IDGrundkurve)
qHt_0_1$IDGrundkurve[length(qHt_0_1$IDGrundkurve)] <- max(unikke_metoder_1$IDGrundkurve) 

qHt_0_1$t <- as.POSIXct(qHt_0_1$t)
unikke_metoder_1$t <- as.POSIXct(unikke_metoder_1$t)


qHt_0_1$IDGrundkurve <- approx(unikke_metoder_1$t,
                           unikke_metoder_1$IDGrundkurve,
                           xout=qHt_0_1$t,method="constant")$y

##################################
# Fastlaeggelse af A, N, H0 ######
##################################
unikke_metoder$fromdate <- strptime(unikke_metoder$fromdate,"%Y-%m-%d %H:%M:%S")

grundkurve_1 <- subset(grundkurve,ID == unikke_stationer_boards$ID[aa] & boardno == unikke_stationer_boards$boardno[aa] & 
                         SERIALNO == unikke_stationer_boards$SERIALNO[aa] & Subcurve == unikke_stationer_boards$Subcurve[aa])

grundkurve_1$IDGrundkurve <- unikke_metoder$IDGrundkurve[match(as.character(grundkurve_1$fromdate),as.character(unikke_metoder$fromdate))]


# unik liste af metoder: 
unik_liste_metoder <- unique(unikke_metoder_1$metode)

for(i in 1:length(unik_liste_metoder)){

unikke_metoder_2 <- subset(unikke_metoder_1,metode ==unik_liste_metoder[i])
qHt_1 <- subset(qHt_0_1,IDGrundkurve %in% unique(c(unikke_metoder_2$IDGrundkurve)))  




if(nrow(qHt_1)>0){

qHt_1 <- merge(qHt_1,grundkurve_1,by.x="IDGrundkurve",by.y=c("IDGrundkurve"))
qHt_1$Subcurve <- qHt_1$Subcurve.x

# Data for grundkurvens begyndelse fjernes...:
#qHt_1 <- subset(qHt_1,!is.na(H))

if(nrow(qHt_1) >0){

# Her beregnes den kotejusterede vandstand i forhold til startkoten: Kote fratrukket startkote. Dvs. skalvandstand justeret for koteændringen:
qHt_1$Hm <- qHt_1$H-qHt_1$Kote


CtrlVandf <- median(qHt_1$q,na.rm=T)

# Udvaelgelse af data for subkurve
if(unikke_stationer_boards$Subcurve[aa]==1 & !length(qHt_1$Hmax[!is.na(qHt_1$Hmax)])==0){
  qHt_1$HmaxTemp <- ifelse(is.na(qHt_1$Hmax),1e99,qHt_1$Hmax)  
  
qHt_1 <- subset(qHt_1,((Hm/10 <= HmaxTemp) | is.na(Hm)))
qHt_1 <- qHt_1[,-c(which(colnames(qHt_1)=="HmaxTemp"))]

}

# Udvaelgelse af data for subkurve
if(unikke_stationer_boards$Subcurve[aa]==2 & !length(qHt_1$Hmax[!is.na(qHt_1$Hmax)])==0){
  qHt_1$HmaxTemp <- ifelse(is.na(qHt_1$Hmax),1e99,qHt_1$Hmax)
  qHt_1 <- subset(qHt_1,((Hm/10 <= HmaxTemp) | is.na(Hm)))
  qHt_1 <- qHt_1[,-c(which(colnames(qHt_1)=="HmaxTemp"))]  
}


if(unik_liste_metoder[i]==2){
# Proportionalmetode: Q(t) = A(t)*(H(t)-H0)^N: konstant H0 & N, dynamisk A.
# A(t) = Q(t)/((H(t)-H0)^N)
qHt_1$A_proportional <- qHt_1$q/((qHt_1$Hm/10-qHt_1$H0)^qHt_1$N)

#styrevandf <- mean(qHt_1$q,na.rm=T)

qHt_1$Hs <- (CtrlVandf/qHt_1$A_proportional)^(1/qHt_1$N)+qHt_1$H0+qHt_1$Kote/10
qHt_1$Hsm <-  qHt_1$Hs- qHt_1$Kote


qHt_1$HsDefault <- (CtrlVandf/qHt_1$A)^(1/qHt_1$N)+qHt_1$H0+qHt_1$Kote/10
qHt_1$HsmDefault <-  qHt_1$HsDefault-qHt_1$Kote


qHt_2 <- with(qHt_1,data.frame(IDGrundkurve,t,q,H,Hm,metode,A,N,H0,Subcurve,Hmax,Hbrendpkt,"ADyn"=A_proportional,"NDyn"=N,
                               "H0Dyn"=H0,Hs,Hsm,"Startkote"=Kote,HsDefault,HsmDefault))  
}
if(unik_liste_metoder[i]==1){
  # Brændpunkt: Q(t) = A(t)*(H(t)-H0)^N: konstant H0, dynamisk N & A.
  qHt_1$Qfikspunkt <-   qHt_1$A*(qHt_1$Hbrendpkt- qHt_1$H0)^qHt_1$N
  qHt_1$NDyn <- (log(qHt_1$q)-log(qHt_1$Qfikspunkt))/(log(qHt_1$Hm/10-qHt_1$H0)-log(qHt_1$Hbrendpkt-qHt_1$H0))
  qHt_1$A_proportional <- exp(log(qHt_1$q)-qHt_1$NDyn*log(qHt_1$Hm/10-qHt_1$H0))
# Styreniveau:  1000
  
  qHt_1$Hs <- (CtrlVandf/qHt_1$A_proportional)^(1/qHt_1$NDyn)+qHt_1$H0+qHt_1$Kote/10
  qHt_1$Hsm <-  qHt_1$Hs- qHt_1$Kote

  qHt_1$HsDefault <- (CtrlVandf/qHt_1$A)^(1/qHt_1$N)+qHt_1$H0+qHt_1$Kote/10
  qHt_1$HsmDefault <-  qHt_1$HsDefault-qHt_1$Kote
  
  
   # qHt_1$QsGrundkurve <- qHt_1$A*(qHt_1$Hs-(qHt_1$H0+qHt_1$Kote/10))^qHt_1$N
#  qHt_1$QFaktor <-1000/qHt_1$QsGrundkurve
  
  
  qHt_2 <- with(qHt_1,data.frame(IDGrundkurve,t,q,H,Hm,metode,A,N,H0,Subcurve,Hmax,Hbrendpkt,"ADyn"=A_proportional,"NDyn"=NDyn,
                                 "H0Dyn"=H0,Hs,Hsm,"Startkote"=Kote,HsDefault,HsmDefault))  
} 

if(unik_liste_metoder[i]==3){
  # Bundforskydning: Q(t) = A(t)*(H(t)-H0)^N: konstant H0, dynamisk N & A.
   qHt_1$NDyn <- qHt_1$N 
  qHt_1$A_proportional <- qHt_1$A
  qHt_1$H0Dyn <- qHt_1$Hm/10-(qHt_1$q/qHt_1$A)^(1/qHt_1$N)
  qHt_1$Hs <- (CtrlVandf/qHt_1$A)^(1/qHt_1$N)+qHt_1$H0Dyn+qHt_1$Kote/10
  qHt_1$Hsm <-  qHt_1$Hs- qHt_1$Kote
  
  qHt_1$HsDefault <- (CtrlVandf/qHt_1$A)^(1/qHt_1$N)+qHt_1$H0+qHt_1$Kote/10
  qHt_1$HsmDefault <-  qHt_1$HsDefault-qHt_1$Kote
  
  
  qHt_2 <- with(qHt_1,data.frame(IDGrundkurve,t,q,H,Hm,metode,A,N,H0,Subcurve,Hmax,Hbrendpkt,"ADyn"=A,"NDyn"=N,
                                 "H0Dyn"=H0Dyn,Hs,Hsm,"Startkote"=Kote,HsDefault,HsmDefault))  
} 
if(unik_liste_metoder[i]==4){
  # Bundforskydning: Q(t) = A(t)*(H(t)-H0)^N: konstant H0, dynamisk N & A.
  qHt_1$NDyn <- qHt_1$N 
  qHt_1$A_proportional <- qHt_1$A
  qHt_1$H0Dyn <- qHt_1$H0

  qHt_1$HsDefault <- (CtrlVandf/qHt_1$A)^(1/qHt_1$N)+qHt_1$H0+qHt_1$Kote/10
  qHt_1$HsmDefault <-  qHt_1$HsDefault-qHt_1$Kote
  
  
  
  qHt_2 <- with(qHt_1,data.frame(IDGrundkurve,t,q,H,Hm,metode,A,N,H0,Subcurve,Hmax,Hbrendpkt,"ADyn"=A,"NDyn"=N,
                                 "H0Dyn"=H0,"Hs"=-999,"Hsm"=-999,"Startkote"=Kote,HsDefault,HsmDefault))  
}
######################################################################
# For at få tidspunkterne for start/slut af grundkurverne med:########
######################################################################

temp <- subset(qHt_1,!is.na(H))


if(!length(unique(qHt_2$H))==1 & nrow(temp)>1){
qHt_2$ADyn <- approx(qHt_2$t,
                     qHt_2$ADyn,
                     xout=qHt_2$t)$y

qHt_2$NDyn <- approx(qHt_2$t,
                     qHt_2$NDyn,
                     xout=qHt_2$t)$y

qHt_2$H0Dyn <- approx(qHt_2$t,
                      qHt_2$H0Dyn,
                      xout=qHt_2$t)$y

qHt_2$Hs <- approx(qHt_2$t,
                      qHt_2$Hs,
                      xout=qHt_2$t)$y} 
##############################################################
##############################################################

}


} else{qHt_2 <- data.frame("IDGrundkurve"=-999,"t"=unikke_metoder_2$t[1],"q"=-999,"H"=-999,
                           "Hm"=-999,"metode"=-999,"A"=-999,"N"=-999,"H0"=-999,"Subcurve"=-999,"Hmax"=-999,
                           "Hbrendpkt"=-999,"ADyn"=-999,"NDyn"=-999,"H0Dyn"=-999,"Hs"=-999,"Hsm"=-999,"Startkote"=-999,
                           "HsDefault"=-999,"HsmDefault"=-999)}


# Opsamling:
qHt_2$ID <- unikke_stationer_boards$ID[aa]
qHt_2$boardno <- unikke_stationer_boards$boardno[aa]
qHt_2$SERIALNO <- unikke_stationer_boards$SERIALNO[aa]

qHt_2$CtrlVandf <- CtrlVandf

opsamling[i] <- list(qHt_2)


}
opsamling <- opsamling[lapply(opsamling,length)>=1]

opsamling_1[aa] <- list(do.call("rbind",opsamling))
print(aa/nrow(unikke_stationer_boards))
#}
}

opsamling_1 <- opsamling_1[lapply(opsamling_1,length)>1]

resultat <- do.call("rbind",opsamling_1)
#resultat <- subset(resultat,!Hm>Hmax*10)
resultat <- with(resultat,resultat[order(ID,SERIALNO,boardno,t,Subcurve),])
resultat <- resultat[!duplicated(resultat[,c("ID","SERIALNO","boardno","t","H")]),]
resultat <- subset(resultat,!is.na(q))
resultat
}



