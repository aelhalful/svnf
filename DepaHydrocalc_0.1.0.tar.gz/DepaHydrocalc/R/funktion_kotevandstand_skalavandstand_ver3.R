#' Calculate water level 
#' 
#' This function calculates the water level for unique stations and boards by taking two inputs: measured water scales and levels. 
#' The function iterates through each unique station and board, calculating the water level for each time point.
#'
#' @details For each unique station and board it calculates the water level from the scale measurements (typically more frequent than level measurements)
#' and level measurements. Using linear interpolation of the level. The function adds a 'nowcast (=system time)' level, setting the
#' nowcast level equal to the last measured level. 
#'   
#' @author Johan Lassen
#' @param waterlevels A data frame that contains the water levels. It must have the following columns:
#'                    - ID: integer, representing the unique identifier for each station.
#'                    - Tidspunkt: integer, representing the timestamp in the format of 'YYYYMMDDHHMM'.
#'                    - Resultat: numeric, representing the results.
#'                    - boardnr: integer, representing the board number.
#' @param levels A data frame that contains the levels. It must have the following columns:
#'               - ID: integer, representing the unique identifier for each station.
#'               - Tidspunkt: integer, representing the timestamp in the format of 'YYYYMMDDHHMM'.
#'               - LEVELVALUE: numeric, representing the level values.
#'               - BOARDNO: integer, representing the board number.
#' @param interpol_startkote: if set to "J": If the level is not available for the first data point (scale), then the level for the first data point is set equal to the first coming level.
#' @return A data frame that includes the calculated water level. The returned data frame will include the following columns:
#'         - ID: integer, representing the unique identifier for each station.
#'         - Tidspunkt: integer, representing the timestamp in the format of 'YYYYMMDDHHMM'.
#'         - Resultat: numeric, representing the scale measurements.
#'         - boardnr: integer, representing the board number.
#'         - Kote: numeric, representing the interpolated level values.
#'         - Vandstand: numeric, representing the calculated water level (Resultat + Kote).
#'         - Tid: POSIXct, representing the timestamp converted from 'Tidspunkt'.
#' @examples
#' waterlevels <- data.frame("ID"=1,"boardnr"=1,"Tidspunkt"=c(201901021200,20200102120000,202101021200,20220121120000),"Resultat"=c(10,10,10,10))
#' levels <- data.frame("ID"=1,"BOARDNO"=1,"Tidspunkt"=c(201901011200,202101011200),"LEVELVALUE"=c(0,10))
#' 
#' resultat <- funktion_kotevandstand_skalavandstand(waterlevels,levels,interpol_startkote='')
#' levels$Tid <- strptime(levels$Tidspunkt,"%Y%m%d%H%M")
#' 
#' ggplot()+geom_point(data=levels,aes(x=as.POSIXct(Tid),y=LEVELVALUE),col="red",shape=1,size=4)+geom_line(data=levels,aes(x=as.POSIXct(Tid),y=LEVELVALUE),col="red")+
#' geom_point(data=resultat,aes(x=as.POSIXct(Tid),y=Vandstand))+ geom_line(data=resultat,aes(x=as.POSIXct(Tid),y=Vandstand))+
#' geom_point(data=resultat,aes(x=as.POSIXct(Tid),y=Resultat),col="blue")+ geom_line(data=resultat,aes(x=as.POSIXct(Tid),y=Resultat),col="blue")+
#' ggtitle("Rød: Kotemåling, Sort: Kotevandstand, Blå: Skalavandstand")

#' @note  Note that a sudden larger unintended change in scale pole (sinking, rising due to ice, accidents etc.) should be followed immediately by a level 
#' level measurement. Also, inserts of estimated levels just before and after the sudden change in scale pole. If not, the unintended in scale pole will be interpolated incorrectly over 
#' the longer time period between two level measurements.
#' @references aa
#' @references aa


funktion_kotevandstand_skalavandstand <- function(waterlevels,levels,interpol_startkote){

input_qcalcctl_0 <- waterlevels
input_levels_0 <- levels  
  
unikkestationer <- unique(input_qcalcctl_0$ID)
unikkestationer <- unikkestationer[unikkestationer %in% unique(c(input_levels_0$ID))]
  
  
dataforberedelse_3_2 <- numeric(1)

for(i in 1:length(unikkestationer)){
  
  dataforberedelse_2 <- with(input_levels_0,input_levels_0[ID == unikkestationer[i],])
  dataforberedelse_2 <- with(dataforberedelse_2,data.frame(ID,Tidspunkt,LEVELVALUE,BOARDNO))
  # Unikke boards:
  boards <- unique(dataforberedelse_2$BOARDNO)
  
  dataforberedelse_3_1 <- numeric(1)
  
  for(j in 1:length(boards)){
    
    # Det antages at koten dd. er lig med koten maalt sidst:
    dataforberedelse_2_1 <- with(dataforberedelse_2,dataforberedelse_2[rev(order(Tidspunkt)) & BOARDNO == boards[j],])
    dataforberedelse_2_1 <- with(dataforberedelse_2_1,dataforberedelse_2_1[rev(order(Tidspunkt)),])
    
    dataforberedelse_2_1_temp <- data.frame("ID" = unikkestationer[i],"Tidspunkt" = as.numeric(as.character(format(Sys.time(),"%Y%m%d%H%M"))),
                                            "LEVELVALUE" = dataforberedelse_2_1$LEVELVALUE[1],
                                            "BOARDNO"=dataforberedelse_2_1$BOARD[1])
    colnames(dataforberedelse_2_1_temp) <- colnames(dataforberedelse_2)
    
    dataforberedelse_2_1 <- rbind(dataforberedelse_2_1,dataforberedelse_2_1_temp)
    dataforberedelse_2_1 <- with(dataforberedelse_2_1,dataforberedelse_2_1[order(Tidspunkt),])
    
    #dataforberedelse_2_1$LEVELVALUE <- ifelse(is.na(dataforberedelse_2_1$LEVELVALUE),0,dataforberedelse_2_1$LEVELVALUE)
    #dataforberedelse_2_1$BOARDNO <- ifelse(is.na(dataforberedelse_2_1$BOARDNO),0,dataforberedelse_2_1$BOARDNO)
    
    
    # QH-dataerne:
    dataforberedelse_3 <- subset(input_qcalcctl_0,ID ==unikkestationer[i])
    dataforberedelse_3 <- subset(dataforberedelse_3 ,boardnr==boards[j])
    
    dataforberedelse_3$Tidspunkt <- as.numeric(substr(dataforberedelse_3$Tidspunkt,1,12))
    dataforberedelse_3 <- with(dataforberedelse_3,dataforberedelse_3[order(Tidspunkt),])
    
    # Koten til hvert af QH-data tidspunkterne:
    
    dataforberedelse_3$Kote <- approx(as.POSIXct(as.character(dataforberedelse_2_1$Tidspunkt),format = "%Y%m%d%H%M"),
                                      dataforberedelse_2_1$LEVELVALUE,
                                      xout=as.POSIXct(as.character(dataforberedelse_3$Tidspunkt),format ="%Y%m%d%H%M"))$y
    
  if(interpol_startkote=="J" & length(dataforberedelse_3$Kote>1)){
    # Hvis den første kote er NA, så sættes lig med den først målte kote: 
    dataforberedelse_3$Kote[1] <- ifelse(is.na(dataforberedelse_3$Kote[1]),dataforberedelse_3$Kote[2],dataforberedelse_3$Kote[1])
  }
    dataforberedelse_3$Vandstand <- dataforberedelse_3$Resultat+dataforberedelse_3$Kote
    diff(dataforberedelse_3$Kote)
    
    dataforberedelse_3_1[j] <- list(dataforberedelse_3)
    
  }
  
  dataforberedelse_3_2[i] <- list(do.call("rbind",dataforberedelse_3_1))
  print(i/length(unikkestationer))
  
}

input_qcalcctl_1 <- do.call("rbind",dataforberedelse_3_2)
#input_qcalcctl_1$EXTKEY <- input_dmuobsnrtab$EXTKEY[match(input_qcalcctl_1$ID,input_dmuobsnrtab$ID)]
input_qcalcctl_1$Tid <- strptime(input_qcalcctl_1$Tidspunkt,"%Y%m%d%H%M")

input_qcalcctl_1
}
