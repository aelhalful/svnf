#' Forecast flow or parameter (q, A, N, H0, Hs).
#' @details Response = f(Year, Month, Waterlevel, Id of rating curve, Lag1 of response). Specific for the parameter A, the parameter N is added to the design matrix: 
#' A = f(Year, Month, Waterlevel, Id of rating curve,N))
#' The design matrix for the regression is made from lm. Optimization procedure for hyper parameters is grid search or optimization using a bayesian approach. 
#' Folds used in the cross-validation procedure is either random or stepwise chronological (ie.: train on data up to time-5, validate on time-4, train on 
#' data up to time-4, validate on time -3, etc.).  
#' 'https://medium.com/@rithpansanga/optimizing-xgboost-a-guide-to-hyperparameter-tuning-77b6e48e289d'
#' http://www.mysmu.edu/faculty/jwwang/post/hyperparameters-tuning-for-xgboost-using-bayesian-optimization/
#' Tjuning of hyperparameters by gridsearch: max_depth = c(2,3, 5),nrounds = (1:5)*20,eta = c(0.3,0.5,0.8),gamma = c(0,2),subsample = 1,min_child_weight = 1,
#' colsample_bytree = c(0.6,0.9)
#' @author Johan Lassen
#' @param inputdata A dataframe with: ID, boardno, SERIALNO, Subcurve, H (water level), Hs/ADyn/NDyn,q, t (time stamp: yyyy-mm-dd HH:MM)
#' @param responsvariabel Scalar: "Hs", "ADyn". "NDyn", or "q"
#' @param hyperparametersoptimization:  Scalar: If set to TRUE, then the input hyperparameters must be defined. Else, the hyperparameters dataframe does not need to be 
#' defined.
#' @param inputhyperparameters:  A dataframe with: max_depth, nrounds, eta, gamma, subsample, min_child_weight, colsample_bytree,
#' SERIALNO, ID, boardno, Subcurve
#' @return A list: 1) RMSE=root of squared mean of winning model,2) gbmGrid_final=hyperparameters of winning model,
#' Model=Winning model trained on all data,feature_betydning=feature importance,Fit=Fitted values of model trained on all data,
#' xgb_train=training data (all),Plot=plot of model result for all data and for the validation fits, Valideringsresultat= Result of validation (observed vs. predicted ),
#' IDs=Identification by station id, board no, serial no and subcurve no)
#' @examples
#' temp1 <- F_to_C(50);
#' temp2 <- F_to_C( c(50, 63, 23) );
#' @export ...
#' @note  For now simple gridsearch is used to optimize the hyper parameters. Other techniques may be preferred!
#' @references Hedeselskabet 2000 ....
#' @references AU 2000 ....


funktion_beregn_q <- function(inputdata,responsvariabel,hyperparametersoptimization,inputhyperparameters){
  
inputdata$Y <- as.numeric(format(inputdata$t,"%Y"))  
inputdata$Mnd <- paste0("Mnd",format(inputdata$t,"%m")) 
inputdata$IDGrundkurveKat <- paste0("Grundkurve",inputdata$IDGrundkurve) 

unikke_serialno_id_boardno_subkurve <- unique(inputdata[,c("SERIALNO","ID","boardno","Subcurve")])  
# Det vælges her kun at medtage én station,board,serial no:
#unikke_serialno_id_boardno_subkurve <- subset(unikke_serialno_id_boardno_subkurve,SERIALNO==1 & boardno == 1)


ResultatDF2 <- numeric(1)
for(h in 1:nrow(unikke_serialno_id_boardno_subkurve)){
  
inputdata_2 <- subset(inputdata,SERIALNO==unikke_serialno_id_boardno_subkurve$SERIALNO[h] & ID == unikke_serialno_id_boardno_subkurve$ID[h] & 
                        boardno == unikke_serialno_id_boardno_subkurve$boardno[h] & Subcurve ==unikke_serialno_id_boardno_subkurve$Subcurve[h])
inputdata_2 <- na.omit(inputdata_2[,c("q","Y","H","IDGrundkurve","NDyn","t","Hs","ADyn","Mnd","IDGrundkurveKat")])
if(nrow(inputdata_2) > 12){

inputdata_2 <- with(inputdata_2,inputdata_2[order(t),])
inputdata_2$tNumerisk <- as.numeric(inputdata_2$t)




inputdata_2 <- with(inputdata_2,inputdata_2[order(t),])
inputdata_2$qLag1 <- c(NA,inputdata_2$q[-nrow(inputdata_2)])
inputdata_2 <- na.omit(inputdata_2)

#################################################
#### Linear regression direkte for respons, q####
#################################################

#lineregress <- lm(q~Y+Mnd+IDGrundkurveKat+H+tNumerisk+0,data=inputdata_2)

if(length(unique(inputdata_2$IDGrundkurveKat)) > 1){
if(responsvariabel=="ADyn"){lineregress <- lm(q~Y*Mnd*H*qLag1+IDGrundkurveKat*NDyn+0,data=inputdata_2)}else
  {lineregress <- lm(q~Y*Mnd*H*qLag1:IDGrundkurveKat+0,data=inputdata_2)}
} else{
  if(responsvariabel=="ADyn"){lineregress <- lm(q~Y*Mnd*H*qLag1+NDyn+0,data=inputdata_2)}else
  {lineregress <- lm(q~Y*Mnd*H*qLag1+0,data=inputdata_2)}
  
}

#############################################
##### XG BOOST direkte på vandføringen ######
#############################################

if(responsvariabel=="NDyn"){
  modelmatricen <- cbind(inputdata_2$NDyn,as.matrix(model.matrix(lineregress)))
  inputdata_2$y <- inputdata_2$NDyn
  }
if(responsvariabel=="ADyn"){modelmatricen <- cbind(inputdata_2$ADyn,as.matrix(model.matrix(lineregress)))
inputdata_2$y <- inputdata_2$ADyn
}
if(responsvariabel=="HDyn"){modelmatricen <- cbind(inputdata_2$H0Dyn,as.matrix(model.matrix(lineregress)))
inputdata_2$y <- inputdata_2$HDyn}
if(responsvariabel=="Q"){modelmatricen <- cbind(inputdata_2$q,as.matrix(model.matrix(lineregress)))
inputdata_2$y <- inputdata_2$Q}
if(responsvariabel=="Hs"){modelmatricen <- cbind(inputdata_2$Hs,as.matrix(model.matrix(lineregress)))
inputdata_2$y <- inputdata_2$Hs}




#modelmatricen <- cbind(dataudvaelgelse_3_1_2_1$LogAmmoniak.ammonium.N,as.matrix(model.matrix(model1_test_lab_1)))

model <- as.matrix(modelmatricen,"dgCMatrix")

if(hyperparametersoptimization ==TRUE){

# Customsing the tuning grid
gbmGrid <-  expand.grid(max_depth = c(2,3, 5), 
                        nrounds = (1:5)*20,    # number of trees
                        # default values below
                        eta = c(0.3,0.5,0.8),
                        gamma = c(0,2),
                        subsample = 1,
                        min_child_weight = 1,
                        colsample_bytree = c(0.6,0.9))
} else{
    gbmGrid_final <- subset(inputhyperparameters, ID == unikke_serialno_id_boardno_subkurve$ID[h] & SERIALNO == unikke_serialno_id_boardno_subkurve$SERIALNO[h] &
                              boardno == unikke_serialno_id_boardno_subkurve$boardno[h] & Subcurve ==unikke_serialno_id_boardno_subkurve$Subcurve[h])
  
  gbmGrid <- gbmGrid_final  
    
}


###################################################
##### Mixed model direkte på vandføringen ########
###################################################


###################
# Alternativ: ######
####################
resultat <- numeric(1)
for(i in 1:nrow(gbmGrid)){
 valideringsfejl <- numeric(1)
  for(j in 1:5){

# Training data:    
endepunkt <- nrow(modelmatricen)-j 
train_x = modelmatricen[1:endepunkt,-1] 
train_y = modelmatricen[1:endepunkt,1]

# Test data: 
startpunkt <- endepunkt+1
slutpunkt <- nrow(modelmatricen)
test_x <- modelmatricen[startpunkt,-1] 
test_y <- modelmatricen[startpunkt,1] 
  
#define final training and testing sets
xgb_train = xgb.DMatrix(data = train_x, label = train_y)
if(length(test_y)==1){xgb_test = xgb.DMatrix(data = t(as.matrix(test_x)), label = test_y)} else{xgb_test = xgb.DMatrix(data = test_x, label = test_y)}   
 
   
     
modelXGBOOST <- xgb.train(data = xgb_train, params=list(booster="gbtree",nthread=10), max.depth = gbmGrid$max_depth[i],eta =gbmGrid$eta[i],gamma=gbmGrid$gamma[i],
         nrounds = gbmGrid$nrounds[i])   

valideringsfejl[j] <- list(data.frame("Fit"=predict(modelXGBOOST,xgb_test),"Observeret"=test_y,j,i))

  }
 temp <- do.call("rbind",valideringsfejl)
temp <- data.frame(gbmGrid[i,],temp)
resultat[i] <- list(temp)
print(i/nrow(gbmGrid))
}

resultatfinal <-do.call("rbind",resultat)
resultatfinal$RMSE <- sqrt((resultatfinal$Fit-resultatfinal$Observeret)^2)

resultatfinal_1 <- with(resultatfinal,aggregate(RMSE,list(i),mean))
resultatfinal_1 <- with(resultatfinal_1,resultatfinal_1[order(x),]) 
colnames(resultatfinal_1) <- c("Id_matrix","RMSE")
resultatfinal_1$Unc <- sqrt(5/qchisq(p=1-.05/2, df=5, lower.tail=FALSE))*resultatfinal_1$RMSE
 

gbmGrid_final <- gbmGrid[resultatfinal_1$Id_matrix[1],]

valideringsresultat <- subset(resultatfinal,i==resultatfinal_1$Id_matrix[1])

train_x = modelmatricen[,-1]
train_y = modelmatricen[,1]
xgb_train = xgb.DMatrix(data = train_x, label = train_y)


#https://stats.stackexchange.com/questions/78079/confidence-interval-of-rmse


modelXGBOOSTFinal = xgb.train(data = xgb_train, params=list(booster="gbtree",nthread=10),max.depth = gbmGrid_final$max_depth,eta =gbmGrid_final$eta,gamma=gbmGrid_final$gamma,
                         nrounds = gbmGrid_final$nrounds)
   
feature_betydning <- tryCatch(xgb.importance(model =modelXGBOOSTFinal),error=function(x)"Fejl")

Fittedev <- predict(modelXGBOOSTFinal,xgb_train)

inputdata_2$Fit <- Fittedev

temp <- inputdata_2[c((nrow(inputdata_2)-(nrow(valideringsresultat)-1)):nrow(inputdata_2)),]
temp <- with(temp,temp[rev(order(t)),])


valideringsresultat$t <- temp$t

p <- ggplot()+geom_point(data=inputdata_2,aes(x=as.POSIXct(t),y=y))+
  geom_line(data=inputdata_2,aes(x=as.POSIXct(t),y=Fit))+
  geom_point(data=valideringsresultat,aes(x=as.POSIXct(t),y=Fit),col="red",shape = 1,size=2)+
  geom_line(data=valideringsresultat,aes(x=as.POSIXct(t),y=Fit),col="red")


ResultatDF <- list("RMSE"=resultatfinal_1[1,],"gbmGrid_final"=gbmGrid_final,"Model"=modelXGBOOSTFinal,"feature_betydning"=feature_betydning,
                   "Fit"=predict(modelXGBOOSTFinal,xgb_train),"Plot"=p,"Valideringsresultat"=valideringsresultat,"IDs"=unikke_serialno_id_boardno_subkurve[h,])



}else{ResultatDF <- list("RMSE"='NA')}


ResultatDF2[h] <- list(ResultatDF)
}
ResultatDF2
}

