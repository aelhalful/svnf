#' Calculation of water flow from the equation: \eqn{Q_{t}=A_{t}*(H_{t}-H_{0,t})^N_{t}}
#'
#' @details Water flow is calculated from the 'steering point and the parameter value \eqn{N_{t}}:
#'
#' \eqn{Q_{t}=A_{t}*(H_{t}-H_{0,t})^N_{t}}
#'
#' \eqn{Q_{Control}=A_{t}*(H_{s,t}-H_{0,t})^N_{t}}
#'
#' \eqn{Q_{t}=Q_{Control}/(H_{s,t}-H_{0,t})^N_{t}*(H_{t}-H_{0,t})^N_{t}}
#'
#' Hence, in order to make a nowcast of the water flow, the parameter value \eqn{N_{t}} and the steering point \eqn{H_{s,t)}} both need to be forecasted.
#'
#' @author Johan Lassen
#' @param loggervandstand A data.frame:ID (integer) = unique id of station, boardnr (integer) = unique id within station id,
#' Tidspunkt = timestamp formatted as the integer yyyymmddhhmmss, Vandstand = kote vandstand
#' @param run_4 A data.frame: ID (integer) = unique id of station, boardno (integer) = unique id within station id,
#' SERIALNO (integer) = unique id within station id, q (float) = water flow, H (float) = water level, t (time) = timestamp formatted as yyyy-mm-dd hh:mm:ss
#' Hs (float) = steering water level, Subcurve (integer) = Subcurve off QH rating curve, IDGrundkurve (integer) = ID of QH rating curve, Hmax (float) = maximum
#' depth for Subcurve, ADyn (float) = dynamic A-parameter of QH rating curve, NDyn (float) = dynamic N-parameter of QH rating curve, H0Dyn = dynamic H0 parameter
#' of QH rating curve.
#' @return calculated flow: ID = ID of station, boardno (integer) = ID of board (within station), Tidspunkt (integer) = time stamp (yymmddhhmm), Vandstand = water level
#' Startkote = level at start of QH rating curve, Hs = depth of steering curve, H0 = dynamic interpolated H0, N = dynamic interpolated N, A = dynamic interpolated A,
#' Q = calculated flow, Subcurve, EXTKEY = ID.
#' @examples
#' ...
#' ...
#' @export ...
#' @note  Only for ...
#' @references Hedeselskabet 2000 ....
#' @references AU 2000 ....
#' @warnings Det skal testes hvorfor Hm er forskellig for samme dato/måling for hhv. delkurve 1 og 2 for station 26000082. Er dette en bug i koden?


funktion_q_beregn_hymer <- function(loggervandstand,run_4){

unikke_stationer_boardno <- unique(with(loggervandstand,data.frame(ID,boardnr)))

resultat <- numeric(1)

for(i in 1:nrow(unikke_stationer_boardno)){

funktion_beregn_q_hymer <- subset(run_4,ID==unikke_stationer_boardno$ID[i] & boardno==unikke_stationer_boardno$boardnr[i])
funktion_beregn_q_hymer <- subset(run_4,ID==unikke_stationer_boardno$ID[i] )


unikke_stationer_boardno_serialno_subcurve <- unique(with(funktion_beregn_q_hymer,data.frame(ID,boardno,SERIALNO,Subcurve)))

loggervandstand_1 <- subset(loggervandstand, ID==unikke_stationer_boardno$ID[i] & boardnr==unikke_stationer_boardno$boardnr[i])

resultat_1 <- numeric(1)
for(j in 1:nrow(unikke_stationer_boardno_serialno_subcurve)){

funktion_beregn_q_hymer_1 <- subset(funktion_beregn_q_hymer,SERIALNO==unikke_stationer_boardno_serialno_subcurve$SERIALNO[j] &
                                      Subcurve==unikke_stationer_boardno_serialno_subcurve$Subcurve[j])

funktion_beregn_q_hymer_1$Tidspunkt <- as.numeric(format(funktion_beregn_q_hymer_1$t,"%Y%m%d%H%M"))

loggervandstand_1$Startkote <- approx(as.POSIXct(as.character(funktion_beregn_q_hymer_1$Tidspunkt),format = "%Y%m%d%H%M"),
                                    funktion_beregn_q_hymer_1$Startkote,
                                    xout=as.POSIXct(as.character(loggervandstand_1$Tidspunkt),format ="%Y%m%d%H%M"))$y

loggervandstand_1$Hs <- approx(as.POSIXct(as.character(funktion_beregn_q_hymer_1$Tidspunkt),format = "%Y%m%d%H%M"),
                                    funktion_beregn_q_hymer_1$Hs,
                                    xout=as.POSIXct(as.character(loggervandstand_1$Tidspunkt),format ="%Y%m%d%H%M"))$y

loggervandstand_1$H0 <- approx(as.POSIXct(as.character(funktion_beregn_q_hymer_1$Tidspunkt),format = "%Y%m%d%H%M"),
                             funktion_beregn_q_hymer_1$H0Dyn,
                             xout=as.POSIXct(as.character(loggervandstand_1$Tidspunkt),format ="%Y%m%d%H%M"))$y

loggervandstand_1$N <- approx(as.POSIXct(as.character(funktion_beregn_q_hymer_1$Tidspunkt),format = "%Y%m%d%H%M"),
                             funktion_beregn_q_hymer_1$NDyn,
                             xout=as.POSIXct(as.character(loggervandstand_1$Tidspunkt),format ="%Y%m%d%H%M"))$y


loggervandstand_1$Hm <- loggervandstand_1$Vandstand/10-loggervandstand_1$Startkote/10
loggervandstand_1$Hs <- loggervandstand_1$Hs-loggervandstand_1$Startkote/10

loggervandstand_1 <- subset(loggervandstand_1,Hm>0)
loggervandstand_1$Q <- 100/((loggervandstand_1$Hs-loggervandstand_1$H0)/(loggervandstand_1$Hm-loggervandstand_1$H0))^loggervandstand_1$N

loggervandstand_1$Subcurve <- unikke_stationer_boardno_serialno_subcurve$Subcurve[j]
loggervandstand_1$SERIAL <- unikke_stationer_boardno_serialno_subcurve$SERIALNO[j]
loggervandstand_1$EXTKEY <- funktion_beregn_q_hymer_1$EXTKEY[1]
resultat_1[j] <- list(loggervandstand_1)
}

temp <- do.call("rbind",resultat_1)
resultat[i] <- list(temp)
}
resultat_final <- do.call("rbind",resultat)
print(i/nrow(unikke_stationer_boardno))
resultat_final
}
